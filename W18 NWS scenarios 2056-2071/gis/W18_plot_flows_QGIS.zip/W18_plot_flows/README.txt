Open W18_plot_flows.qgz in QGIS 3.x (layers load from ./layers).
Plots filled by average flow (m3/d per plot) in a blue gradient, darker = more; one year at a time (2031, 2056, 2071, 2100).
Plots with no flow are empty. Existing plots outlined by land use; proposed plots outlined light grey.
Fields: W18_plots_2026_2100_fields.md and W18_settlements_2026_2100_fields.md. Basemap: Google satellite hybrid (web, needs internet).
