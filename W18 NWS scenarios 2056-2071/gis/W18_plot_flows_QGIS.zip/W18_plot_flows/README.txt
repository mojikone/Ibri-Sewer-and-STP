Open W18_plot_flows.qgz in QGIS 3.x (layers load from ./layers).
Plots filled by average flow (m3/d per plot) in a blue gradient, darker = more; one year at a time (2031, 2056, 2071, 2100).
Plots with no flow are empty. Existing plots outlined by land use; proposed plots outlined light grey.
Fields: W18_plots_2026_2100_fields.md and W18_settlements_2026_2100_fields.md. Basemap: Google satellite hybrid (web, needs internet).
W18_MOHUP_DATA_NA_growth_plots.xlsx: the team's sheet 'MOHUP DATA - NA' with the growth plots of the plot layer in column C.
Group 'SC1 sewer conditions': SC1 (design year 2056) re-laid from the SewerGEMS design, one condition at a time;
a saved print layout for each (Project > Layouts: SC1 C0 ... C3), exported in sc1_conditions/maps/.
C0 as designed: pipes by velocity at the 2031 peak. C1-C3: pipes above DN200 steepened to reach 0.75 m/s at the
2031 peak with gradients up to 0.50 / 0.75 / 1.00 %, one gradient per street run, and the subnetworks split where they
stay deeper than 12 m (new stations, gravity joins). Every map: pipes over 3.0 m/s at the 2056 peak, outfalls with
name and depth. Each condition's numbers: sc1_conditions/<condition>_SUMMARY.md.
